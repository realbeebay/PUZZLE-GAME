
    const puzzlesArrangement = [1, 2, 3, 4, 5, 6, 7, 8];
    const mainGameDiv = document.getElementsByClassName("main-game-div")[0];
    const puzzlesItem = document.getElementsByClassName("puzzles-item");
    const ErrorSpan = document.getElementById("error-span");
    

    function puzzlesStart() {
    	document.getElementById("reset-game").style.display = "none";
        ErrorSpan.innerHTML = "";
        if(puzzlesItem.length == 9) {
            mainGameDiv.innerHTML = "";
            const shufflePuzzles = puzzlesArrangement.sort(() => Math.random() - 0.5);
            for (let x = 0; x < shufflePuzzles.length; x++) {
                const puzzlesNumber = (x + 1);
                const createsPuzzlesButton = document.createElement("button");
                createsPuzzlesButton.className = "puzzles-item";
                createsPuzzlesButton.innerHTML = shufflePuzzles[x];
                createsPuzzlesButton.value = shufflePuzzles[x];
                createsPuzzlesButton.setAttribute("onclick", "movePuzzle(this);");

                const createsLastPuzzlesButton = document.createElement("button");
                createsLastPuzzlesButton.id = "path-space";
                createsLastPuzzlesButton.className = "puzzles-item";
                createsLastPuzzlesButton.innerHTML = 9;
                createsLastPuzzlesButton.value = "9";
                
                if(puzzlesNumber <= 7){
                    mainGameDiv.appendChild(createsPuzzlesButton);
                }else{
                    if(puzzlesNumber == 8){
                        mainGameDiv.appendChild(createsPuzzlesButton);
                        mainGameDiv.appendChild(createsLastPuzzlesButton);
                        ErrorSpan.innerHTML = "Game Starts";
                        document.getElementById("reset-game").style.display = "inline-block";
                    }
                }
            }
        }else{
            mainGameDiv.innerHTML = "";
            for (let x = 0; x < 9; x++) {
                let puzzlesNumber = Math.floor(x + 1);
                let createsPuzzlesButton = document.createElement("button");
                createsPuzzlesButton.className = "puzzles-item";
                createsPuzzlesButton.innerHTML = puzzlesNumber;
                if(puzzlesNumber <= 8){
                    mainGameDiv.appendChild(createsPuzzlesButton);
                }else{
                    if(puzzlesNumber == 9){
                        createsPuzzlesButton.id = "path-space";
                        ErrorSpan.innerHTML = "Game Loading...";
                        mainGameDiv.appendChild(createsPuzzlesButton);
                        setTimeout(() => {
                            puzzlesStart();
                            document.getElementById("reset-game").style.display = "inline-block";
                        }, 3000);
                    }
                }
            }
        }
    }

    puzzlesStart();

    function movePuzzle(htmlTAGDetails) {
        let puzzleDetails = htmlTAGDetails;
        let puzzleValue = puzzleDetails.value;
        
        let getPuzzleItems = document.getElementsByClassName("puzzles-item");
		let puzzleValueArr = [];
		for(let x = 0; x < 9; x++){
			puzzleValueArr[x] = getPuzzleItems[x].value;
		}
        
        const puzzlePosition = checkPuzzlePosition(Number(puzzleValue));
        const puzzlePosibleMove = checkPuzzlePosibleMove(puzzlePosition);
        
		if(puzzlePosibleMove <= 8){
			//ErrorSpan.innerHTML = "Puzzle Moved";
        	initiateMove(puzzleValueArr, puzzlePosition, puzzlePosibleMove);
        }
        
        if(puzzlePosibleMove == "error"){
        	ErrorSpan.innerHTML = "Puzzle Not Moveable";
        }
    }
    
    function checkPuzzlePosition(puzzleValue){
    	let getPuzzleItems = document.getElementsByClassName("puzzles-item");
    	let puzzleItemIndex = "";
    	for(let x = 0; x < getPuzzleItems.length; x++){
    		if(getPuzzleItems[x].value == puzzleValue){
    			puzzleItemIndex = x;
    		}
    	}
    	return puzzleItemIndex;
    }
    
    function checkPuzzlePosibleMove(puzzlePosition){
    	const topMove = (puzzlePosition - 3);
    	const leftMove = (puzzlePosition - 1);
    	const rightMove = (puzzlePosition + 1);
   		const bottomMove = (puzzlePosition + 3);
   		
   		const topMovePuzzle = document.getElementsByClassName("puzzles-item")[topMove];
   		const leftMovePuzzle = document.getElementsByClassName("puzzles-item")[leftMove];
   		const rightMovePuzzle = document.getElementsByClassName("puzzles-item")[rightMove];
   		const bottomMovePuzzle = document.getElementsByClassName("puzzles-item")[bottomMove];
   		
   		const leftMoveImpossible = [2, 5];
   		const rightMoveImpossible = [3, 6];
   		if((topMove >= 0) && (topMovePuzzle != "undefined") && (topMovePuzzle.value == 9)){
   			return topMove;
   		}else{
   			if((leftMove >= 0) && (leftMove <= 8) && (leftMovePuzzle != "undefined") && (leftMovePuzzle.value == 9)){
   				if(leftMoveImpossible.indexOf(leftMove) == -1){
   					return leftMove;
   				}else{
   					return "error";
   				}
   			}else{
   				if((rightMove >= 0) && (rightMove <= 8) && (rightMovePuzzle != "undefined") && (rightMovePuzzle.value == 9)){
   					if(rightMoveImpossible.indexOf(rightMove) == -1){
   						return rightMove;
   					}else{
   						return "error";
   					}
   				}else{
   					if((bottomMove >= 0) && (bottomMove <= 8) && (bottomMovePuzzle != "undefined") && (bottomMovePuzzle.value == 9)){
   						return bottomMove;
   					}else{
   						return "error";
   					}
   				}
   			}
   		}
    }
    
    function initiateMove(puzzleValueArr, firstElementPostion, emptyElementPostion){
    	mainGameDiv.innerHTML = "";
    	for (let x = 0; x < 9; x++) {
    		let createsPuzzlesButton = document.createElement("button");
    		createsPuzzlesButton.className = "puzzles-item";
    		createsPuzzlesButton.setAttribute("onclick", "movePuzzle(this);");
    		
    		if((x !== firstElementPostion) && (x !== emptyElementPostion)){
    			createsPuzzlesButton.innerHTML = puzzleValueArr[x];
    			createsPuzzlesButton.value = puzzleValueArr[x];
    			mainGameDiv.appendChild(createsPuzzlesButton);
    		}
    			
    		if((x == firstElementPostion)){
    			let createsLastPuzzlesButton = document.createElement("button");
    			createsLastPuzzlesButton.className = "puzzles-item";
    			createsLastPuzzlesButton.innerHTML = puzzleValueArr[emptyElementPostion];
    			createsLastPuzzlesButton.value = puzzleValueArr[emptyElementPostion];
    			mainGameDiv.appendChild(createsLastPuzzlesButton);
    			document.getElementsByClassName("puzzles-item")[firstElementPostion].id = "path-space";
    		}
    			
    		if((x == emptyElementPostion)){
    			createsPuzzlesButton.innerHTML = puzzleValueArr[firstElementPostion];
    			createsPuzzlesButton.value = puzzleValueArr[firstElementPostion];
    			mainGameDiv.appendChild(createsPuzzlesButton);
    		}
    	}
    	
    	checkWon();
    }

	function checkWon(){
		let puzzleRange = [1, 2, 3, 4, 5, 6, 7, 8];
		let getPuzzleItems = document.getElementsByClassName("puzzles-item");
		let puzzleValueArr = [];
		for(let x = 0; x < 8; x++){
			puzzleValueArr[x] = getPuzzleItems[x].value;
		}
		if(puzzleRange.join() == puzzleValueArr.join()){
			ErrorSpan.innerHTML = "You WON!";
		}
	}

	//Reset Game
	document.getElementById("reset-game").addEventListener("click", () => {
		if(confirm("Do You Want To Reset This Puzzle?")) {
			puzzlesStart();
		}
	});